import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { MomenttextPage } from './momenttext';

@NgModule({
  declarations: [
    MomenttextPage,
  ],
  imports: [
    IonicPageModule.forChild(MomenttextPage),
  ],
})
export class MomenttextPageModule {}
