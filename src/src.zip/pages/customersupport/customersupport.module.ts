import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { CustomersupportPage } from './customersupport';

@NgModule({
  declarations: [
    CustomersupportPage,
  ],
  imports: [
    IonicPageModule.forChild(CustomersupportPage),
  ],
})
export class CustomersupportPageModule {}
