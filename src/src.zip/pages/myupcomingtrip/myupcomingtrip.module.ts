import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { MyupcomingtripPage } from './myupcomingtrip';

@NgModule({
  declarations: [
    MyupcomingtripPage,
  ],
  imports: [
    IonicPageModule.forChild(MyupcomingtripPage),
  ],
})
export class MyupcomingtripPageModule {}
