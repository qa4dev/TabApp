import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { TakeacrossborderPage } from './takeacrossborder';

@NgModule({
  declarations: [
    TakeacrossborderPage,
  ],
  imports: [
    IonicPageModule.forChild(TakeacrossborderPage),
  ],
})
export class TakeacrossborderPageModule {}
