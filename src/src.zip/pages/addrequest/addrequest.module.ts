import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AddrequestPage } from './addrequest';

@NgModule({
  declarations: [
    AddrequestPage,
  ],
  imports: [
    IonicPageModule.forChild(AddrequestPage),
  ],
})
export class AddrequestPageModule {}
