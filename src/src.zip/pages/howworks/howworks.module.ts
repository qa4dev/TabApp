import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { HowworksPage } from './howworks';

@NgModule({
  declarations: [
    HowworksPage,
  ],
  imports: [
    IonicPageModule.forChild(HowworksPage),
  ],
})
export class HowworksPageModule {}
