import { Component } from '@angular/core';
import { IonicPage, NavController, ModalController } from 'ionic-angular';
import { Commonservice } from '../../providers/commonservice';
import { Apiservice } from '../../providers/apiservice';

@IonicPage()
@Component({
    selector: 'page-home',
    templateUrl: 'home.html'
})
export class HomePage {
    
    slides: any;
    currentIndex = 0;
    result: any;
    constructor(
        public navCtrl: NavController,
        public modalCtrl: ModalController,
        private commonservice: Commonservice,
        private apiservice: Apiservice,
    ) {

        // this.slides = [
        //     {
        //         title: "Fasion",
        //         description: "The <b>Ionic Component Documentation</b> showcases a number of useful components that are included out of the box with Ionic.",
        //         image: "assets/imgs/ica-slidebox-img-1.png",
        //     },
        //     {
        //         title: "Food",
        //         description: "<b>Ionic Framework</b> is an open source SDK that enables developers to build high quality mobile apps with web technologies like HTML, CSS, and JavaScript.",
        //         image: "assets/imgs/ica-slidebox-img-2.png",
        //     },
        //     {
        //         title: "Shoes",
        //         description: "The <b>Ionic Cloud</b> is a cloud platform for managing and scaling Ionic apps with integrated services like push notifications, native builds, user auth, and live updating.",
        //         image: "assets/imgs/ica-slidebox-img-3.png",
        //     },
        //     {
        //         title: "Electronic",
        //         description: "The <b>Ionic Cloud</b> is a cloud platform for managing and scaling Ionic apps with integrated services like push notifications, native builds, user auth, and live updating.",
        //         image: "assets/imgs/ica-slidebox-img-4.png",
        //     },
        //     {
        //         title: "Mechanic",
        //         description: "The <b>Ionic Component Documentation</b> showcases a number of useful components that are included out of the box with Ionic.",
        //         image: "assets/imgs/ica-slidebox-img-1.png",
        //     },
        //     {
        //         title: "Science",
        //         description: "<b>Ionic Framework</b> is an open source SDK that enables developers to build high quality mobile apps with web technologies like HTML, CSS, and JavaScript.",
        //         image: "assets/imgs/ica-slidebox-img-2.png",
        //     },
        //     {
        //         title: "Maths",
        //         description: "The <b>Ionic Cloud</b> is a cloud platform for managing and scaling Ionic apps with integrated services like push notifications, native builds, user auth, and live updating.",
        //         image: "assets/imgs/ica-slidebox-img-3.png",
        //     },
        //     {
        //         title: "English",
        //         description: "The <b>Ionic Cloud</b> is a cloud platform for managing and scaling Ionic apps with integrated services like push notifications, native builds, user auth, and live updating.",
        //         image: "assets/imgs/ica-slidebox-img-4.png",
        //     }
        // ];

        this.homedata();
    }

    homedata(){
        this.commonservice.showLoader();
        this.apiservice.homepage_data(null).then((res) => {
            this.commonservice.hideLoader();
            this.result = res;
            console.log(this.result);
            if (this.result.RespCode == "2003") {
                this.slides = this.result.sliderImages;
            } else {
                var msg = 'Data not fetch successfully';            
                this.commonservice.showAlert(msg);
            }
        }, (err) => {
            this.commonservice.hideLoader();
            var msg = 'Please check your internet connection or wait for server to respond';
            this.commonservice.showAlert(msg);
        });
    }

    nextSlide() {
        this.slides.slideNext();
    }

    previousSlide() {
        this.slides.slidePrev();
    }

    onSlideChanged() {
        this.currentIndex = this.slides.getActiveIndex();
        console.log('Slide changed! Current index is', this.currentIndex);
    }

  
}
